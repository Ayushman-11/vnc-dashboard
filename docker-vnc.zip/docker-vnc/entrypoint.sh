#!/bin/bash
set -e

USER=kali
HOME_DIR=/home/$USER
VNC_PORT=3
GEOMETRY=1280x800
XSTARTUP=/usr/lib/gemini-cli/xstartup

# Ensure user exists
id $USER &>/dev/null || useradd -m -s /bin/bash $USER

# Create necessary directories
mkdir -p $HOME_DIR/.vnc $HOME_DIR/.config/tigervnc
chown -R $USER:$USER $HOME_DIR/.vnc $HOME_DIR/.config/tigervnc

# Copy password file and set permissions
if [ -f /vnc/passwd ]; then
    cp /vnc/passwd $HOME_DIR/.vnc/passwd
    chmod 600 $HOME_DIR/.vnc/passwd
    chown $USER:$USER $HOME_DIR/.vnc/passwd
else
    echo "[ERROR] /vnc/passwd not found!"
    exit 1
fi

# Copy xstartup if provided
if [ -f /vnc/xstartup ]; then
    cp /vnc/xstartup $XSTARTUP
    chmod +x $XSTARTUP
fi

# Avoid migration warning
export TIGERVNC_HOME=$HOME_DIR/.config/tigervnc

echo "[+] Starting TigerVNC server on :$VNC_PORT..."

# Run VNC as user in foreground, forcing password file
su - $USER -s /bin/bash -c "vncserver :$VNC_PORT -fg -geometry $GEOMETRY -xstartup $XSTARTUP -localhost no -rfbauth $HOME_DIR/.vnc/passwd"

# Keep container alive as fallback
tail -f /dev/null

